import React from 'react';
import { motion } from 'framer-motion';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface SocialLinkProps {
  icon: LucideIcon;
  text: string;
  href: string;
}

const SocialLink: React.FC<SocialLinkProps> = ({ icon: Icon, text, href }) => {
  const shimmerAnimation = {
    initial: { backgroundPosition: "0 0" },
    animate: { 
      backgroundPosition: ["0 0", "200% 0"],
      transition: {
        repeat: Infinity,
        repeatType: "reverse",
        duration: 3,
      }
    }
  };

  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      className="relative flex items-center space-x-2 px-6 py-3 rounded-full overflow-hidden"
      style={{
        background: 'linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.2))',
      }}
    >
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-purple-500/20 via-pink-500/20 to-purple-500/20 bg-[length:200%_100%]"
        variants={shimmerAnimation}
        initial="initial"
        animate="animate"
      />
      <Icon className="text-purple-300 relative z-10" size={20} />
      <span className="relative z-10">{text}</span>
    </motion.a>
  );
};

export default SocialLink;