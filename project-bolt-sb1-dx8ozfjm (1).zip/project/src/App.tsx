import React, { useEffect, useState } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { MapPin, User, Calendar, Youtube, Send, ShoppingBag, Rocket, Wrench, Users, Trophy, Star, Zap, Sparkles, Globe, Award } from 'lucide-react';
import ParticlesBackground from './components/ParticlesBackground';
import CustomCursor from './components/CustomCursor';
import SocialLink from './components/SocialLink';
import TypewriterText from './components/TypewriterText';

function App() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const controls = useAnimation();

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const shimmerAnimation = {
    initial: { backgroundPosition: "0 0" },
    animate: { 
      backgroundPosition: ["0 0", "100% 100%"],
      transition: {
        repeat: Infinity,
        repeatType: "reverse",
        duration: 3,
      }
    }
  };

  const floatAnimation = {
    initial: { y: 0 },
    animate: {
      y: [-5, 5],
      transition: {
        repeat: Infinity,
        repeatType: "reverse",
        duration: 2,
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0F0416] to-[#1F0B33] text-white relative overflow-hidden scroll-smooth">
      <CustomCursor mousePosition={mousePosition} />
      <ParticlesBackground />
      
      <div className="container mx-auto px-4 py-12">
        {/* Имя */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <motion.h1 
            className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-300 to-purple-400 bg-[length:200%_200%]"
            variants={shimmerAnimation}
            initial="initial"
            animate="animate"
          >
            Ильдар
          </motion.h1>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Левая колонка */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <motion.div 
              className="glassmorphism p-6 rounded-xl"
              variants={floatAnimation}
              initial="initial"
              animate="animate"
            >
              <h2 className="text-2xl font-bold mb-4">👤 Обо мне</h2>
              <div className="space-y-4">
                <motion.div 
                  whileHover={{ scale: 1.05, x: 10 }}
                  className="flex items-center space-x-3"
                >
                  <MapPin className="text-purple-300" />
                  <span>Россия</span>
                </motion.div>
                <motion.div 
                  whileHover={{ scale: 1.05, x: 10 }}
                  className="flex items-center space-x-3"
                >
                  <User className="text-purple-300" />
                  <span>Башкир</span>
                </motion.div>
                <motion.div 
                  whileHover={{ scale: 1.05, x: 10 }}
                  className="flex items-center space-x-3"
                >
                  <Calendar className="text-purple-300" />
                  <span>13 лет</span>
                </motion.div>
              </div>
            </motion.div>

            {/* Build a Boat услуги */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="glassmorphism p-6 rounded-xl"
              variants={floatAnimation}
              whileHover={{ scale: 1.02 }}
            >
              <h2 className="text-2xl font-bold mb-4 flex items-center">
                <Rocket className="mr-2 text-purple-300" />
                🚀 Build a Boat - Творческие Услуги
              </h2>
              <div className="space-y-3">
                <motion.div whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Wrench className="text-purple-300" size={18} />
                  <span>Дизайн уникальных построек</span>
                </motion.div>
                <motion.div whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <MapPin className="text-purple-300" size={18} />
                  <span>Создание тематических карт</span>
                </motion.div>
                <motion.div whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Rocket className="text-purple-300" size={18} />
                  <span>Разработка механизмов и машин</span>
                </motion.div>
                <motion.div whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Users className="text-purple-300" size={18} />
                  <span>Консультации по игровым механикам</span>
                </motion.div>
                <motion.div whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Star className="text-purple-300" size={18} />
                  <span>Индивидуальный подход к проектам</span>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>

          {/* Правая колонка */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <motion.div 
              className="glassmorphism p-6 rounded-xl"
              variants={floatAnimation}
              initial="initial"
              animate="animate"
              whileHover={{ scale: 1.02 }}
            >
              <h2 className="text-2xl font-bold mb-4">⚡ Накрутка на Социальные Сети</h2>
              <div className="space-y-6">
                <div className="space-y-2">
                  <ul className="space-y-3">
                    <motion.li 
                      whileHover={{ x: 10 }} 
                      className="flex items-center space-x-2"
                    >
                      <Zap className="text-purple-300" size={18} />
                      <span>🚀 Профессиональная / быстрая накрутка</span>
                    </motion.li>
                    <motion.li 
                      whileHover={{ x: 10 }} 
                      className="flex items-center space-x-2"
                    >
                      <Sparkles className="text-purple-300" size={18} />
                      <span>⭐ Создание популярности вам и на ваш контент</span>
                    </motion.li>
                    <motion.li 
                      whileHover={{ x: 10 }} 
                      className="flex items-center space-x-2"
                    >
                      <Globe className="text-purple-300" size={18} />
                      <span>🌐 Большой выбор Соц Сетей для накрутки</span>
                    </motion.li>
                    <motion.li 
                      whileHover={{ x: 10 }} 
                      className="flex items-center space-x-2"
                    >
                      <Award className="text-purple-300" size={18} />
                      <span>👥 Работа с целевой аудиторией</span>
                    </motion.li>
                  </ul>
                </div>
              </div>
            </motion.div>

            {/* Дополнительные элементы */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="glassmorphism p-6 rounded-xl"
              variants={floatAnimation}
              whileHover={{ scale: 1.02 }}
            >
              <h2 className="text-2xl font-bold mb-4">✨ Дополнительные элементы</h2>
              <ul className="space-y-3">
                <motion.li whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Star className="text-purple-300" size={18} />
                  <span>✨ Изысканные визуальные эффекты</span>
                </motion.li>
                <motion.li whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Trophy className="text-purple-300" size={18} />
                  <span>🎨 Гармоничные цветовые градиенты</span>
                </motion.li>
                <motion.li whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Star className="text-purple-300" size={18} />
                  <span>📝 Утонченная типографика</span>
                </motion.li>
                <motion.li whileHover={{ x: 10 }} className="flex items-center space-x-2">
                  <Trophy className="text-purple-300" size={18} />
                  <span>🎭 Безупречная синхронизация анимаций</span>
                </motion.li>
              </ul>
            </motion.div>
          </motion.div>
        </div>

        {/* Социальные сети */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-12"
        >
          <motion.div 
            className="glassmorphism p-6 rounded-xl"
            variants={floatAnimation}
            initial="initial"
            animate="animate"
          >
            <h2 className="text-2xl font-bold mb-6">🌐 Социальные сети</h2>
            <div className="flex flex-wrap gap-6 justify-center">
              <SocialLink
                icon={ShoppingBag}
                text="FunPay"
                href="https://funpay.com/users/13040168/"
              />
              <SocialLink
                icon={Send}
                text="Telegram"
                href="https://t.me/imildar"
              />
              <SocialLink
                icon={Youtube}
                text="YouTube"
                href="https://youtube.com/@NEUROILDAR"
              />
            </div>
          </motion.div>
        </motion.div>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12 text-center text-sm text-purple-300"
        >
          Created by @imildar 💫
        </motion.footer>
      </div>
    </div>
  );
}

export default App;