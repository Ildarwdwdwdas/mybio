import React from 'react';
import { motion } from 'framer-motion';

interface CustomCursorProps {
  mousePosition: { x: number; y: number };
}

const CustomCursor: React.FC<CustomCursorProps> = ({ mousePosition }) => {
  return (
    <>
      <motion.div
        className="fixed pointer-events-none z-50"
        style={{
          x: mousePosition.x - 8,
          y: mousePosition.y - 8,
          background: 'linear-gradient(45deg, #6366f1, #a855f7, #ec4899)',
          width: '16px',
          height: '16px',
          borderRadius: '50%',
          mixBlendMode: 'screen',
          filter: 'blur(1px)',
        }}
      />
      <motion.div
        className="fixed pointer-events-none z-50"
        style={{
          x: mousePosition.x - 24,
          y: mousePosition.y - 24,
          width: '48px',
          height: '48px',
          borderRadius: '50%',
          border: '2px solid rgba(167, 139, 250, 0.3)',
          transition: 'all 0.1s ease',
        }}
      />
      <motion.div
        className="fixed pointer-events-none z-50"
        style={{
          x: mousePosition.x - 4,
          y: mousePosition.y - 4,
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          background: '#fff',
          opacity: 0.5,
        }}
      />
    </>
  );
};

export default CustomCursor;